package org.jboss.resteasy.test.microprofile.config.resource;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

@ApplicationPath("app2")
public class MicroProfileConfigUseGlobalApplication2 extends Application {

}
