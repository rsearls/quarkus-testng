package org.jboss.resteasy.test.form.resource;


import org.jboss.resteasy.annotations.Body;

public class FormBodyResourceForm {
   @Body
   public String body;
}
