package org.jboss.resteasy.test.response.resource;

public class ResponseHeaderExceptionMapperRuntimeException extends RuntimeException {
}
