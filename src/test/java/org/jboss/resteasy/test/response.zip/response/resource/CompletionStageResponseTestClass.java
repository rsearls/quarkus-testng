package org.jboss.resteasy.test.response.resource;

public class CompletionStageResponseTestClass
{
   String s;

   public CompletionStageResponseTestClass(final String s) {
      this.s = s;
   }
}
