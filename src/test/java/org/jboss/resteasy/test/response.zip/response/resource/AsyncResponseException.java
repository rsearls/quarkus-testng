package org.jboss.resteasy.test.response.resource;

@SuppressWarnings("serial")
public class AsyncResponseException extends RuntimeException
{

}
