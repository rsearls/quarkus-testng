package org.jboss.resteasy.test.client.proxy.resource;

public class UnauthorizedHttpCodeObject {

}
