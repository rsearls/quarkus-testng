package org.jboss.resteasy.test.client.proxy.resource.GenericEntities;

public interface MultipleGenericEntitiesProxy extends MultipleGenericEntities<String, EntityExtendingBaseEntity> {

}
