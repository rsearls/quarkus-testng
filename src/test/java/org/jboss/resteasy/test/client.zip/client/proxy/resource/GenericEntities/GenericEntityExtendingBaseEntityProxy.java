package org.jboss.resteasy.test.client.proxy.resource.GenericEntities;

public interface GenericEntityExtendingBaseEntityProxy extends GenericEntityExtendingBaseEntity<EntityExtendingBaseEntity> {

}

