package org.jboss.resteasy.test.client.exception.resource;

public class ClientExceptionsData {
   public final String data;
   public final String type;

   public ClientExceptionsData(final String data, final String type) {
      this.data = data;
      this.type = type;
   }
}
