package org.jboss.resteasy.test.client.proxy.resource;

public class MediaTypeCaseSensitivityStuff {
   private String name;

   public MediaTypeCaseSensitivityStuff(final String name) {
      this.name = name;
   }

   public String getName() {
      return name;
   }
}
