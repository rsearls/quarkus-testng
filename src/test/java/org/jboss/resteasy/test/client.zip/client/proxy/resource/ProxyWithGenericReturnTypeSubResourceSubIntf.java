package org.jboss.resteasy.test.client.proxy.resource;

public interface ProxyWithGenericReturnTypeSubResourceSubIntf extends ProxyWithGenericReturnTypeSubResourceIntf<String> {
}
