package org.jboss.resteasy.test.exception.resource;

public class ExceptionMapperCustomRuntimeException extends RuntimeException {
}
