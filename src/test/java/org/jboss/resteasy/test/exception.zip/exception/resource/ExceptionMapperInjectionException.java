package org.jboss.resteasy.test.exception.resource;

public class ExceptionMapperInjectionException extends RuntimeException {
}
