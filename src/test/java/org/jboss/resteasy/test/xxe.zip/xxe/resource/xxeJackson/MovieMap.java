package org.jboss.resteasy.test.xxe.resource.xxeJackson;

import java.util.HashMap;

public class MovieMap<K, V> extends HashMap<K, V> {
   private static final long serialVersionUID = -4947257779972800629L;

}
