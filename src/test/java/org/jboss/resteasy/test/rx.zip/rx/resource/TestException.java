package org.jboss.resteasy.test.rx.resource;

public class TestException extends Exception {

   private static final long serialVersionUID = -1827713152234765715L;

   public TestException(final String message) {
      super(message);
   }
}
