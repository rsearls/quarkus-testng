package org.jboss.resteasy.test.validation.resource;

import javax.ws.rs.POST;

public class ValidationExceptionSuperResource {
   @POST
   public void test(String s) {
   }
}
