package org.jboss.resteasy.test.validation.resource;

public interface ValidationComplexResourceWithClassConstraintInterface {

   String getS();
   String getT();

}
