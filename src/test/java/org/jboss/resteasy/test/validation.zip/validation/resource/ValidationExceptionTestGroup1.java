package org.jboss.resteasy.test.validation.resource;

public interface ValidationExceptionTestGroup1 {
}
