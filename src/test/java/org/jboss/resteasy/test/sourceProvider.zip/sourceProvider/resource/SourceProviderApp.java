package org.jboss.resteasy.test.sourceProvider.resource;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

@ApplicationPath("/")
public class SourceProviderApp extends Application {
}
