package org.jboss.resteasy.test.interceptor.resource;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

@ApplicationPath("/")
public class CustomTestApp extends Application
{
}
