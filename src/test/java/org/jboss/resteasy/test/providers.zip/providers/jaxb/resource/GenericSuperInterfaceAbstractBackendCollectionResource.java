package org.jboss.resteasy.test.providers.jaxb.resource;

public abstract class GenericSuperInterfaceAbstractBackendCollectionResource<R extends GenericSuperInterfaceBaseResource, Q /* extends GenericSuperInterfaceIVdcQueryable */>
      extends GenericSuperInterfaceAbstractBackendResource<R, Q> {
}
