package org.jboss.resteasy.test.providers.jaxb.resource;

public class GenericSuperInterfaceBackendResource extends GenericSuperInterfaceBaseBackendResource {

}
