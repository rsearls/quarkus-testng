package org.jboss.resteasy.test.providers.noproduces.resource;

public class Foo {
   private String s;

   public Foo(final String s) {
      this.s = s;
   }

   public String getS() {
      return s;
   }
}
