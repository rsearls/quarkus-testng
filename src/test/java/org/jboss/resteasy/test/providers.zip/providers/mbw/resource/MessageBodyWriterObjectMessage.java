package org.jboss.resteasy.test.providers.mbw.resource;

public class MessageBodyWriterObjectMessage {

   private String s;
   public MessageBodyWriterObjectMessage(final String s) { this.s = s; }
   public String getS() { return s; }
   public void setS(String s) { this.s = s; }
}
