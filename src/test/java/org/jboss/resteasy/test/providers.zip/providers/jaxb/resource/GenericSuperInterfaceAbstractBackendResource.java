package org.jboss.resteasy.test.providers.jaxb.resource;

public class GenericSuperInterfaceAbstractBackendResource<R extends GenericSuperInterfaceBaseResource, Q /* extends GenericSuperInterfaceIVdcQueryable */>
      extends GenericSuperInterfaceBackendResource {

}
