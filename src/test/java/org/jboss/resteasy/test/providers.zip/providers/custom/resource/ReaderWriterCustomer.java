package org.jboss.resteasy.test.providers.custom.resource;

public class ReaderWriterCustomer {
   private String name;

   public String getName() {
      return name;
   }

   public void setName(String name) {
      this.name = name;
   }
}
