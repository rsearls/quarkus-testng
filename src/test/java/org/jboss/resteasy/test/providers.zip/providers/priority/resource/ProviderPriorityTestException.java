package org.jboss.resteasy.test.providers.priority.resource;

public class ProviderPriorityTestException extends Exception {
   private static final long serialVersionUID = 1L;
}
