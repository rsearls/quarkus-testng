@javax.xml.bind.annotation.XmlSchema(namespace = "http://creaity.de/homecontrol/rest/types/v1", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package org.jboss.resteasy.test.providers.jaxb.resource.homecontrol;
