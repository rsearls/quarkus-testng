package org.jboss.resteasy.test.providers.custom.resource;

public enum ProviderContextInjectionEnumProvider {
   TCK, CTS, JAXRS;
}
