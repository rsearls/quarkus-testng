package org.jboss.resteasy.test.providers.jaxb.resource;


public class GenericResourceOtherAbstractResource<T> extends GenericResourceAbstractResource<T> {
}
