package org.jboss.resteasy.test.providers.custom.resource;

import javax.ws.rs.Consumes;
import javax.ws.rs.ext.Provider;

/**
 * This is the dummy class to get annotations from it
 */
@Provider
@Consumes
public abstract class ResponseGetAnnotationsAnnotatedClass {

}
