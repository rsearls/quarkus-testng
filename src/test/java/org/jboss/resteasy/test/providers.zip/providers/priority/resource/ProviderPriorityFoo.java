package org.jboss.resteasy.test.providers.priority.resource;

public class ProviderPriorityFoo {
   private String foo;

   public ProviderPriorityFoo(final String foo) {this.foo = foo;}

   public String getFoo() {return foo;}
}
