package org.jboss.resteasy.test.providers.jaxb.resource;

import java.io.Serializable;

public class GenericSuperInterfaceGuid implements Serializable {

}
