package org.jboss.resteasy.test.providers.multipart.resource;

public class ProxyResource implements ProxyApiService {
   @Override
   public void postAttachment(ProxyAttachment attachment, String key) {
   }
}
