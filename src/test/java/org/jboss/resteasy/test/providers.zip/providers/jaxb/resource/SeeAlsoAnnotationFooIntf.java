package org.jboss.resteasy.test.providers.jaxb.resource;

import javax.xml.bind.annotation.XmlSeeAlso;

@XmlSeeAlso(SeeAlsoAnnotationRealFoo.class)
public interface SeeAlsoAnnotationFooIntf {
}
