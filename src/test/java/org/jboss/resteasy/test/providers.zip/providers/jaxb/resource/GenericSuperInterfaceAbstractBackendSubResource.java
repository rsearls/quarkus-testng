package org.jboss.resteasy.test.providers.jaxb.resource;

public class GenericSuperInterfaceAbstractBackendSubResource<R extends GenericSuperInterfaceBaseResource, Q /* extends GenericSuperInterfaceIVdcQueryable */> extends
      GenericSuperInterfaceAbstractBackendResource<R, Q> {

}
