package org.jboss.resteasy.test.providers.jackson2.jsonfilter.resource;

public enum PersonType {
   CUSTOMER,
   EMPLOYER,
   TURTLE
}
