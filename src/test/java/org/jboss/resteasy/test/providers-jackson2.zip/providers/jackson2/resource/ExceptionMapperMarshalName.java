package org.jboss.resteasy.test.providers.jackson2.resource;

public class ExceptionMapperMarshalName {
   String first;

   public ExceptionMapperMarshalName() {
   }

   public ExceptionMapperMarshalName(final String first) {
      this.first = first;
   }

   public String getFirst() {
      return first;
   }

   public void setFirst(String first) {
      this.first = first;
   }
}
