package org.jboss.resteasy.test.providers.jackson2.resource;

/**
 * A missing JSON annotation is intended.  This causes the needed exception
 * for testing.
 * User: rsearls
 * Date: 10/13/16
 */
public class MyEntity {
}
