package org.jboss.resteasy.test.providers.jackson2.resource;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

@ApplicationPath("/")
public class CustomJackson2ProviderApplication extends Application {

}
