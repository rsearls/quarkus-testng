package org.jboss.resteasy.test.providers.jackson2.resource;

public interface TestJsonView
{

}
