package org.jboss.resteasy.test.providers.jackson2.whitelist;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

/**
 * @author bmaxwell
 */
@ApplicationPath("/")
public class JaxRsActivator extends Application {
}
