package org.jboss.resteasy.test.asynch.resource;

public interface AsyncInjectionContextInterface
{
   int foo();
}
