package org.jboss.resteasy.test.resource.param.resource;

public enum StringParamUnmarshallerFruit {
   ORANGE,
   PEAR
}
