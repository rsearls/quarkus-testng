package org.jboss.resteasy.test.resource.path.resource;

public class  LocatorSubResourceReturningThisParamEntityWithConstructor extends LocatorSubResourceReturningThisParamEntityPrototype {
   public LocatorSubResourceReturningThisParamEntityWithConstructor(final String arg) {
      value = arg;
   }
}
