package org.jboss.resteasy.test.resource.basic.resource;

public interface ParameterSubResDoubleInterface extends ParameterSubResGenericInterface<Double> {
}
