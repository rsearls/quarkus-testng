package org.jboss.resteasy.test.resource.param.resource;

public class FormParamEntityWithConstructor extends FormParamEntityPrototype {
   public FormParamEntityWithConstructor(final String arg) {
      value = arg;
   }
}
