package org.jboss.resteasy.test.resource.basic.resource;

public class ParameterSubResConcreteSubImpl extends ParameterSubResSubImpl<Integer> {
   public ParameterSubResConcreteSubImpl(final String path) {
      super(path);
   }
}
