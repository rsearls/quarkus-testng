package org.jboss.resteasy.test.resource.path.resource;

public class LocatorWithClassHierarchyParamEntityWithConstructor extends LocatorWithClassHierarchyParamEntityPrototype {
   public LocatorWithClassHierarchyParamEntityWithConstructor(final String arg) {
      value = arg;
   }
}
