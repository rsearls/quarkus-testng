package org.jboss.resteasy.test.resource.param.resource;

public interface HeaderDelegateInterface3 extends HeaderDelegateInterface1 {
}
