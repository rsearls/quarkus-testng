package org.jboss.resteasy.test.resource.param.resource;

public class HeaderDelegateSubDelegate<T> extends HeaderDelegateDelegate<T> {
}
