package org.jboss.resteasy.test.resource.param.resource;

public abstract class FormParamEntityPrototype {
   protected String value;

   public String getValue() {
      return value;
   }
}
