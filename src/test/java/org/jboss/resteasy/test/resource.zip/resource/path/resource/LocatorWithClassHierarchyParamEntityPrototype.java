package org.jboss.resteasy.test.resource.path.resource;

public abstract class LocatorWithClassHierarchyParamEntityPrototype {
   protected String value;

   public String getValue() {
      return value;
   }
}
