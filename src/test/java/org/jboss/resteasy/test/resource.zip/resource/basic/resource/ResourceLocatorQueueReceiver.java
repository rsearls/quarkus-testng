package org.jboss.resteasy.test.resource.basic.resource;

public class ResourceLocatorQueueReceiver extends ResourceLocatorReceiver {

}
