package org.jboss.resteasy.test.resource.param.resource;

public class ParamConverterPOJO {
   private String name;

   public String getName() {
      return name;
   }

   public void setName(String name) {
      this.name = name;
   }
}
