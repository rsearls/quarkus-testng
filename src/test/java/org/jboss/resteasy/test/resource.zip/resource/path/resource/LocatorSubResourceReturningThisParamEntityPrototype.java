package org.jboss.resteasy.test.resource.path.resource;

public abstract class LocatorSubResourceReturningThisParamEntityPrototype {
   protected String value;

   public String getValue() {
      return value;
   }
}
