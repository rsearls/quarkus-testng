package org.jboss.resteasy.test.core.servlet.resource;

public class ServletConfigException extends RuntimeException {
}
