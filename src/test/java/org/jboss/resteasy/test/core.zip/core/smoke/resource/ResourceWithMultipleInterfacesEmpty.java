package org.jboss.resteasy.test.core.smoke.resource;


public interface ResourceWithMultipleInterfacesEmpty {
}
