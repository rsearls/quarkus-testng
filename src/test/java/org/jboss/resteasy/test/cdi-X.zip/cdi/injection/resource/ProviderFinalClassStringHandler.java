package org.jboss.resteasy.test.cdi.injection.resource;

public class ProviderFinalClassStringHandler {
   private String a;

   public String getA() {
      return a;
   }

   public void setA(String a) {
      this.a = a;
   }
}
