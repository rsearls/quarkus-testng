package org.jboss.resteasy.test.cdi.basic.resource;

public class EjbExceptionUnwrapFooException extends RuntimeException {
   private static final long serialVersionUID = 3316574183792636233L;
}
