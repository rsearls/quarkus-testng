package org.jboss.resteasy.test.cdi.extensions.resource;

public interface ScopeExtensionObsolescent {

}
