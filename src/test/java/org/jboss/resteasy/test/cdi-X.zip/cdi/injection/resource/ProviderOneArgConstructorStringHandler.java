package org.jboss.resteasy.test.cdi.injection.resource;

public class ProviderOneArgConstructorStringHandler {
   private String c;

   public String getC() {
      return c;
   }

   public void setC(String c) {
      this.c = c;
   }
}
