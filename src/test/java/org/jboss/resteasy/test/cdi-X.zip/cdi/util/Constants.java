package org.jboss.resteasy.test.cdi.util;

import javax.ws.rs.core.MediaType;

public class Constants {
   public static final String MEDIA_TYPE_TEST_XML = "application/test+xml";
   public static final MediaType MEDIA_TYPE_TEST_XML_TYPE = MediaType.valueOf(MEDIA_TYPE_TEST_XML);
}
