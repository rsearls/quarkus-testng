package org.jboss.resteasy.test.cdi.basic.resource;

public class BeanReaderWriterConfigBean {
   public String version() {
      return "1.1";
   }
}
