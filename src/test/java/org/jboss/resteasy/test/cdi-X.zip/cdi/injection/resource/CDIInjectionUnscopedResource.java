package org.jboss.resteasy.test.cdi.injection.resource;

import javax.ws.rs.Path;

@Path("/unscoped")
public class CDIInjectionUnscopedResource {
}
