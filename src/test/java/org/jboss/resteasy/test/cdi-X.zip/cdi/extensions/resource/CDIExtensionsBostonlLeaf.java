package org.jboss.resteasy.test.cdi.extensions.resource;

@CDIExtensionsBoston
public class CDIExtensionsBostonlLeaf {
}
