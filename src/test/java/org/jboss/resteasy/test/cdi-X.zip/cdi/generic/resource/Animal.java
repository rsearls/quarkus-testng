package org.jboss.resteasy.test.cdi.generic.resource;

public class Animal {
}
