package org.jboss.resteasy.test.cdi.injection.resource;

import javax.enterprise.context.Dependent;

@Dependent
@CDIInjectionScopeInheritingStereotype
public class CDIInjectionStereotypedDependentScope {
}
