package org.jboss.resteasy.test.cdi.modules.resource;

import javax.ejb.Stateless;

@Stateless
@CDIModulesInjectableBinder
public class CDIModulesInjectable implements CDIModulesInjectableIntf {
}
