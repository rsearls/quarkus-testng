package org.jboss.resteasy.test.cdi.basic.resource;

import javax.ejb.Remote;

@Remote
public interface EJBRemoteResource extends EJBResourceParent {
}
