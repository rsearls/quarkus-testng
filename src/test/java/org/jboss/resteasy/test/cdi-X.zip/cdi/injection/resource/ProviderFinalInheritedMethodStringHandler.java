package org.jboss.resteasy.test.cdi.injection.resource;

public class ProviderFinalInheritedMethodStringHandler {
   private String b;

   public String getB() {
      return b;
   }

   public void setB(String b) {
      this.b = b;
   }
}
