package org.jboss.resteasy.test.cdi.injection.resource;

public enum UserType {

   TYPE_ONE,
   TYPE_TWO;

}
