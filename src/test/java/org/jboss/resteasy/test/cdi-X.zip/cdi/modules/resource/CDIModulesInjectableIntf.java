package org.jboss.resteasy.test.cdi.modules.resource;

import javax.ejb.Local;

@Local
public interface CDIModulesInjectableIntf {
}
