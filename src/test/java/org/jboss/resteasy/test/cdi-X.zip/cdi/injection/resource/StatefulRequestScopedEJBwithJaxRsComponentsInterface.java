package org.jboss.resteasy.test.cdi.injection.resource;

import javax.ejb.Local;

@Local
public interface StatefulRequestScopedEJBwithJaxRsComponentsInterface extends ReverseInjectionEJBInterface {
}
